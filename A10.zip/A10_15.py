import chessmoves
chessmoves.run()
